import rospy
from std_msgs.msg import Empty
from geometry_msgs.msg import Pose
import math

i=0
posinitial=0
distance=0

def callback(data):
    global i
    global posinitial
    global distance
    if i==0:
        posinitial=data.position
        rospy.loginfo("i first time %s ",posinitial)
        i=i+1
    else:
        pos=data.position
        newpos=(pos.x-posinitial.x)**2+(pos.y-posinitial.y)**2+(pos.z-posinitial.z)**2
        distance=math.sqrt(newpos)
    
        
    

def move():
    # Starts a new node
    rospy.init_node('robot_drone', anonymous=True)
    takeoff_publisher = rospy.Publisher('/drone/takeoff', Empty, queue_size=10)
    sub_once =rospy.Subscriber("drone/gt_pose", Pose, callback)
    land_publisher = rospy.Publisher('/drone/land', Empty, queue_size=10)
    vel_msg = Empty()
    rospy.loginfo("Drone is taking off")
    
    while not rospy.is_shutdown():
        takeoff_publisher.publish(vel_msg)
        # check the distance from the wall unti it becomes 2m then land the drone
        if int(distance)>=2:
           rospy.loginfo("Attention!! Drone is 2m from the wall")
           sub_once.unregister()
           land_publisher.publish(vel_msg)
           rospy.loginfo("Drone is landing")
           rospy.signal_shutdown("Test Ended Successfully"); 
        else:
            rospy.loginfo("distance is %s ",distance)        
    

if __name__ == '__main__':
    try:
        #Testing our function
        move()
    except rospy.ROSInterruptException: pass
